import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import pool from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { rows } = await pool.query(`
    SELECT ec.*, cl.name AS list_name
    FROM email_campaigns ec
    LEFT JOIN contact_lists cl ON cl.id = ec.list_id
    ORDER BY ec.created_at DESC
  `)
  return NextResponse.json({ campaigns: rows })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { name, subject, html_template, from_name, from_email, list_id, ai_personalise } = body

  if (!name?.trim())          return NextResponse.json({ error: 'Name required' },     { status: 400 })
  if (!subject?.trim())       return NextResponse.json({ error: 'Subject required' },  { status: 400 })
  if (!html_template?.trim()) return NextResponse.json({ error: 'Template required' }, { status: 400 })

  const { rows } = await pool.query(
    `INSERT INTO email_campaigns
       (name, subject, html_template, from_name, from_email, list_id, ai_personalise)
     VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
    [
      name.trim(), subject.trim(), html_template,
      from_name  ?? 'i3 Engage',
      from_email ?? 'hello@i3technologies.co.ke',
      list_id    || null,
      ai_personalise ?? false,
    ]
  )
  return NextResponse.json({ campaign: rows[0] }, { status: 201 })
}
